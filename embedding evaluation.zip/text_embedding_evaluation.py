import time
import psutil
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer

# -------------------------------
# Utility functions
# -------------------------------

def measure_memory():
    """Return current memory usage in MB."""
    process = psutil.Process()
    return process.memory_info().rss / (1024 * 1024)

def nearest_neighbors(embeddings, items, top_k=3):
    """Return qualitative nearest neighbors using cosine similarity."""
    normed = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
    sims = np.dot(normed, normed.T)
    results = []
    for i in range(len(items)):
        nn_idx = sims[i].argsort()[::-1][1:top_k+1]  # skip self
        results.append({
            "query": items[i],
            "neighbors": [items[j] for j in nn_idx]
        })
    return results[:3]  # show 3 examples for brevity

# -------------------------------
# Text model evaluation
# -------------------------------

def eval_text_models(texts, models):
    results = []
    for model_name in models:
        print(f"\nEvaluating text model: {model_name}")
        model = SentenceTransformer(model_name)

        mem_before = measure_memory()
        start = time.time()
        embeddings = model.encode(texts, batch_size=8, convert_to_numpy=True)
        latency = (time.time() - start) / len(texts)
        mem_after = measure_memory()

        dim = embeddings.shape[1]
        mem_used = mem_after - mem_before

        nn_examples = nearest_neighbors(embeddings, texts)

        results.append({
            "model": model_name,
            "latency_per_text": latency,
            "dimension": dim,
            "memory_MB": mem_used,
            "nn_examples": nn_examples
        })
    return pd.DataFrame(results), results

# -------------------------------
# Run evaluation
# -------------------------------

if __name__ == "__main__":
    # Load your sampled CSV
    df = pd.read_csv("data/mimic_cxr_dataset/dataset.csv")

    # Take a small subset of findings/impressions for benchmarking
    texts = (df["findings"].dropna().tolist()[:10] +
             df["impression"].dropna().tolist()[:10])

    text_models = [
        "sentence-transformers/all-MiniLM-L6-v2",
        "sentence-transformers/multi-qa-MiniLM-L6-cos-v1",
        "emilyalsentzer/Bio_ClinicalBERT"
    ]

    df_results, raw_results = eval_text_models(texts, text_models)

    print("\n=== Text Model Results (Quantitative) ===")
    print(df_results[["model","latency_per_text","dimension","memory_MB"]])

    print("\n=== Nearest-Neighbour Examples (Qualitative) ===")
    for r in raw_results:
        print(f"\nModel: {r['model']}")
        for ex in r["nn_examples"]:
            print(f"Query: {ex['query']}")
            print(f"Neighbors: {ex['neighbors']}")

