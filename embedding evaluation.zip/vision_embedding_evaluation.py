import time
import torch
import psutil
import numpy as np
import pandas as pd
from PIL import Image
from transformers import CLIPProcessor, CLIPModel

# -------------------------------
# Utility functions
# -------------------------------

def measure_memory():
    """Return current memory usage in MB."""
    process = psutil.Process()
    return process.memory_info().rss / (1024 * 1024)

def nearest_neighbors(embeddings, items, top_k=3):
    """Return qualitative nearest neighbors using cosine similarity."""
    normed = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
    sims = np.dot(normed, normed.T)
    results = []
    for i in range(len(items)):
        nn_idx = sims[i].argsort()[::-1][1:top_k+1]  # skip self
        results.append({
            "query": items[i],
            "neighbors": [items[j] for j in nn_idx]
        })
    return results

# -------------------------------
# Image model evaluation
# -------------------------------

def eval_image_models(filepaths, models):
    all_results = {}
    for model_name in models:
        print(f"\nEvaluating image model: {model_name}")
        model = CLIPModel.from_pretrained(model_name)
        processor = CLIPProcessor.from_pretrained(model_name)

        images = [Image.open(fp) for fp in filepaths]

        mem_before = measure_memory()
        start = time.time()
        inputs = processor(images=images, return_tensors="pt", padding=True)
        with torch.no_grad():
            embeddings = model.get_image_features(**inputs).cpu().numpy()
        latency = (time.time() - start) / len(images)
        mem_after = measure_memory()

        dim = embeddings.shape[1]
        mem_used = mem_after - mem_before

        nn_examples = nearest_neighbors(embeddings, filepaths)

        all_results[model_name] = {
            "latency_per_image": latency,
            "dimension": dim,
            "memory_MB": mem_used,
            "nn_examples": nn_examples
        }
    return all_results

# -------------------------------
# Run evaluation
# -------------------------------

if __name__ == "__main__":
    # Load your sampled CSV
    df = pd.read_csv("data/mimic_cxr_dataset/dataset.csv")

    # Take a few image filepaths
    filepaths = df["filepath"].dropna().tolist()[:10]

    image_models = [
        "openai/clip-vit-base-patch32",
        "openai/clip-vit-large-patch14",
    ]

    results = eval_image_models(filepaths, image_models)

    print("\n=== Image Model Results (Quantitative) ===")
    for model_name, r in results.items():
        print(f"{model_name}: latency={r['latency_per_image']:.3f}s, dim={r['dimension']}, mem={r['memory_MB']:.1f}MB")

    print("\n=== Nearest-Neighbour Examples (Qualitative, same query across models) ===")
    # Pick the first query image for comparison
    query_image = filepaths[0]
    print(f"\nQuery image: {query_image}")
    for model_name, r in results.items():
        # find neighbors for this query
        neighbors = next(ex["neighbors"] for ex in r["nn_examples"] if ex["query"] == query_image)
        print(f"Model {model_name} neighbors: {neighbors}")

